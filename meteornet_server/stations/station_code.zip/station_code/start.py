#!/usr/bin/env python3

from internals import station_control

if __name__ == "__main__":
    station_control.run()
