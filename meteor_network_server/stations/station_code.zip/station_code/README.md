Meteor Network Station
=====

An automated meteor station software for Petnica Meteor Network. The automation includes turning camera on at night and off in the morning, opening and closing camera shutter, measuring outside temperature and humidity, and sending this information to a central server that overviews the whole network.

Running
=====

Code has been tested on Linux and Windows, both 32 and 64 bit.
To run, place the project on the partition where meteor data will be stored and execute main.py with administrator privileges. (Requires Python 3.5+).
