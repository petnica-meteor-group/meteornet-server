# Serial Com

Provides C routines for convenient serial communication between a computer (includes Linux and Windows implementations) and a microcontroller (includes avr implementation).
Include `serial_com.h` in your code to use.
